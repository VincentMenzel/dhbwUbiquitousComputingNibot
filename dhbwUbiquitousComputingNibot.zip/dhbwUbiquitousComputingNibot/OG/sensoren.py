
#
# Sensorenabfrage - Robo - Test 1
# Board: Metro M4 Express
# Sensoren: Waveshare Tracker Sensor (5x Analog)
# 05.07.21 - wb
# v0.2
#

import board
import time
from analogio import AnalogIn

# Die Liniensensoren sind an A0 bis A4 angeschlossen
analog_Pin1 = AnalogIn(board.A0)
analog_Pin2 = AnalogIn(board.A1)
analog_Pin3 = AnalogIn(board.A2)
analog_Pin4 = AnalogIn(board.A3)
analog_Pin5 = AnalogIn(board.A4)

def sensor_ADchange(analogWert):
    grenzwert_Weiss = 250  # Alles über diesem Wert ist "Weiss erkannt"

    # Messwerte:
    # Tisch und Blatt (weiß): 330 - 370
    # Schwarz: 70 - 200

    # Analogwerte in Digitalwerte aendern
    if analogWert > grenzwert_Weiss:
        digitalWert = 0  # Weiss erkannt
    else:
        digitalWert = 1  # Schwarz erkannt

    return digitalWert

# Liefert Digitalwerte zurück (0 = weiß, 1 = schwarz)
def sensorAbfrage():

    # Analogwerte der Sensoren lesen
    SensorDaten1 = round(analog_Pin1.value / 100)
    SensorDaten2 = round(analog_Pin2.value / 100)
    SensorDaten3 = round(analog_Pin3.value / 100)
    SensorDaten4 = round(analog_Pin4.value / 100)
    SensorDaten5 = round(analog_Pin5.value / 100)

    # Digitalwerte holen (0 = weiß, 1 = schwarz)
    sensorWert_1D = sensor_ADchange(SensorDaten1)
    sensorWert_2D = sensor_ADchange(SensorDaten2)
    sensorWert_3D = sensor_ADchange(SensorDaten3)
    sensorWert_4D = sensor_ADchange(SensorDaten4)
    sensorWert_5D = sensor_ADchange(SensorDaten5)

    sensorWerte = [sensorWert_1D, sensorWert_2D, sensorWert_3D, sensorWert_4D, sensorWert_5D]  # schreibt alle Sensorwerte in eine Liste

    #print(SensorDaten1, SensorDaten2, SensorDaten3, SensorDaten4, SensorDaten5)
    #print(sensorWerte)
    #time.sleep(0.25)

    return sensorWerte
