# Roboter entwickeln

Repository für das Projekt "Nibot - Fahrenden Roboter entwickeln"

DHBW Heidenheim
:--------------:
![DHBW Logo](logo/dhbw.svg)

<h1 align="center">
  Roboter entwickeln
</h1>



<h2 align="center">Projekt</h2>



<p align="center">
  des Studiengangs Wirtschaftsinformatik<br/>
  an der Dualen Hochschule Baden-Württemberg Heidenheim 
</p>



<p align="center">
  von<br/>
  Vincent Menzel, Marius Lindt, Enrico Bachus<br/>
  22.04.2021 
</p>





<p>
Bearbeitungszeitraum: 11 Wochen </br>
Vorgelegt von: Vincent Menzel, Marius Lindt, Enrico Bachus </br>
Matrikelnummer; Kurs: 5855524, 5446728, 7605326; WWI19A </br>
Gutachter der Dualen Hochschule: Herr Beckers </br>
</p>
